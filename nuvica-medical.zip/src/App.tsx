import {
  ArrowUpRight,
  ChevronDown,
  Phone,
  Plus,
  Brain,
  Activity,
  Users,
  Award,
  Wind,
  HeartPulse,
  Microscope,
  Baby,
  Bone,
  Eye,
  ArrowRight,
  Mail,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Clock
} from 'lucide-react';
import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';

import heroDoctor from './assets/images/hero_doctor_1781406180790.jpg';
import medicalLungs from './assets/images/medical_lungs_1781406192087.jpg';
import hospitalExterior from './assets/images/hospital_exterior_1781406204488.jpg';
import maleDoctor from './assets/images/male_doctor_1781406468043.jpg';
import femaleDoctor2 from './assets/images/female_doctor_2_1781406483813.jpg';

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const departments = [
  { name: "Cardiology", icon: HeartPulse, desc: "Comprehensive heart care and cardiovascular diagnostics.", color: "bg-red-100 text-red-500" },
  { name: "Neurology", icon: Brain, desc: "Advanced brain treatments and neurological therapies.", color: "bg-teal-100 text-teal-600" },
  { name: "Pediatrics", icon: Baby, desc: "Expert care and compassionate treatment for children.", color: "bg-blue-100 text-blue-500" },
  { name: "Orthopedics", icon: Bone, desc: "Specialized care for bones, joints, and musculoskeletal issues.", color: "bg-orange-100 text-orange-500" },
  { name: "Ophthalmology", icon: Eye, desc: "Advanced vision care, surgeries, and eye health diagnostics.", color: "bg-purple-100 text-purple-500" },
  { name: "Laboratory", icon: Microscope, desc: "Precise diagnostics and fast testing in our modern lab.", color: "bg-indigo-100 text-indigo-500" },
];

const doctors = [
  { name: "Dr. Sarah Jenkins", role: "Chief Medical Officer", img: heroDoctor },
  { name: "Dr. Michael Chen", role: "Head of Cardiology", img: maleDoctor },
  { name: "Dr. Emily Wong", role: "Pediatric Specialist", img: femaleDoctor2 },
];

export default function App() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const yBackground = useTransform(scrollYProgress, [0, 1], [0, 300]);

  return (
    <div ref={containerRef} className="min-h-screen relative overflow-x-hidden bg-gradient-to-b from-[#8CA3C0] via-[#E2EBF5] to-[#F1F6FB] font-sans pb-0">
      {/* Huge Background Text */}
      <motion.div 
        style={{ y: yBackground }}
        className="absolute top-0 left-1/2 -translate-x-1/2 text-[25vw] font-outfit font-bold text-white/40 select-none z-0 tracking-tighter w-full text-center overflow-hidden h-[400px] leading-tight pointer-events-none mix-blend-overlay"
      >
        NUVICA
      </motion.div>

      <div className="max-w-[1240px] mx-auto px-6 relative z-10">
        
        {/* Navbar */}
        <motion.nav 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-between py-8"
        >
          <div className="flex items-center gap-2 cursor-pointer group">
            <div className="bg-[#1A3454] p-1.5 rounded-lg flex items-center justify-center w-8 h-8 group-hover:bg-[#4ADE80] transition-colors">
              <Plus size={20} className="text-[#4ADE80] group-hover:text-white transition-colors" strokeWidth={3} />
            </div>
            <span className="text-2xl font-bold font-outfit text-[#1A3454] tracking-tight">Nuvica</span>
          </div>

          <div className="hidden md:flex items-center gap-10 text-[15px] font-semibold text-[#1A3454]">
            <a href="#" className="border-b-[3px] border-[#1A3454] pb-1">Home</a>
            <a href="#about" className="hover:opacity-70 transition-opacity">About</a>
            <a href="#departments" className="hover:opacity-70 transition-opacity flex items-center gap-1">
              Departments <ChevronDown size={16} strokeWidth={2.5}/>
            </a>
            <a href="#doctors" className="hover:opacity-70 transition-opacity">Doctors</a>
            <a href="#contact" className="hover:opacity-70 transition-opacity">Contact</a>
          </div>

          <button className="hidden md:flex items-center gap-4 bg-white hover:bg-gray-50 text-[#1A3454] font-bold px-6 py-2.5 rounded-full shadow-[0_2px_15px_rgba(0,0,0,0.06)] transition-all hover:shadow-md hover:-translate-y-0.5 group">
             Book Appointment
             <div className="bg-[#4ADE80] p-1.5 rounded-full text-white group-hover:rotate-45 transition-transform duration-300">
               <ArrowUpRight size={16} strokeWidth={3} />
             </div>
          </button>
        </motion.nav>

        {/* Hero Section */}
        <div className="grid grid-cols-12 gap-6 mt-6 md:mt-12 items-center">
          
          {/* Left Hero Text */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="col-span-12 md:col-span-4 flex flex-col justify-center relative z-20 pb-16"
          >
            <motion.div 
               whileHover={{ scale: 1.05 }}
               className="inline-flex items-center gap-2 bg-white/90 backdrop-blur-md border border-white/40 px-4 py-2 rounded-full text-[13px] font-bold text-[#1A3454] w-fit shadow-sm uppercase tracking-wide cursor-default"
            >
              <Activity size={16} className="text-[#1A3454] animate-pulse" />
              Fast Treatment
            </motion.div>
            <h1 className="text-[72px] font-outfit font-bold text-white mt-8 leading-[1.05] tracking-tight drop-shadow-sm">
              <span className="block overflow-hidden"><motion.span initial={{ y: "100%" }} animate={{ y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="block">QUICK</motion.span></span>
              <span className="block overflow-hidden"><motion.span initial={{ y: "100%" }} animate={{ y: 0 }} transition={{ duration: 0.5, delay: 0.4 }} className="block">SMART</motion.span></span>
              <span className="block overflow-hidden"><motion.span initial={{ y: "100%" }} animate={{ y: 0 }} transition={{ duration: 0.5, delay: 0.5 }} className="block">MEDIC</motion.span></span>
            </h1>
            <p className="text-[#1A3454] text-[15px] mt-6 max-w-[300px] leading-relaxed font-semibold">
              Nuvica is your destination for world-class treatments, compassionate doctors, and precise diagnostics all under one roof.
            </p>
            <motion.button 
               whileHover={{ y: -2 }}
               whileTap={{ scale: 0.98 }}
               className="mt-10 flex items-center gap-4 bg-[#1A3454] hover:bg-[#152a45] text-white font-bold px-7 py-4 rounded-full w-fit transition-all hover:shadow-xl hover:shadow-black/10 group"
            >
               Explore More
               <div className="bg-white/20 p-1.5 rounded-full text-white group-hover:bg-white group-hover:text-[#1A3454] transition-colors">
                 <ArrowUpRight size={16} strokeWidth={3} className="group-hover:rotate-45 transition-transform duration-300" />
               </div>
            </motion.button>
          </motion.div>

          {/* Center Doctor Image */}
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="col-span-12 md:col-span-4 relative flex justify-center items-end hidden md:flex h-full pb-8"
          >
            <div className="w-full max-w-[340px] aspect-[4/5] overflow-visible relative">
               <div className="absolute inset-0 bg-[#E2EBF5] rounded-t-full rounded-b-3xl overflow-hidden shadow-2xl">
                 <img src={heroDoctor} alt="Dr." className="w-full h-full object-cover object-top hover:scale-[1.02] transition-transform duration-700" />
               </div>
               
               {/* Floating Badges */}
               <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -bottom-6 -left-12 bg-white rounded-[24px] p-3.5 shadow-xl flex items-center gap-4 z-30"
                >
                  <div className="bg-[#1A3454] p-2.5 rounded-xl text-white">
                     <Award size={20} />
                  </div>
                  <div className="pr-2">
                    <div className="font-outfit font-bold text-[#1A3454] text-[19px] leading-tight">22 Years</div>
                    <div className="text-[11px] text-[#1A3454]/60 font-semibold uppercase tracking-wider mt-0.5">Medical Excellence</div>
                  </div>
               </motion.div>

               <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 1, duration: 0.6 }}
                  className="absolute top-16 -right-10 bg-white rounded-3xl p-4 shadow-xl flex flex-col items-center z-30 pr-8 pl-6"
                >
                 <div className="text-[28px] font-outfit font-bold text-[#1A3454] leading-none mb-1">490</div>
                 <div className="text-[10px] uppercase tracking-widest text-[#1A3454]/60 font-bold mb-2">Awards</div>
                 <div className="bg-[#E2EBF5] p-2 rounded-full absolute -bottom-4 bg-white shadow-sm border border-gray-100">
                    <Award size={20} className="text-[#1A3454]" />
                 </div>
               </motion.div>
            </div>
          </motion.div>

          {/* Right Lungs Image */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="col-span-12 md:col-span-4 relative flex justify-center items-center hidden md:flex pl-8"
          >
            <div className="relative">
              {/* Fake UI Tag */}
              <motion.div 
                 animate={{ y: [0, 8, 0] }}
                 transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                 className="absolute -top-16 right-0 bg-white rounded-full py-2 px-4 shadow-[0_8px_30px_rgb(0,0,0,0.08)] flex items-center gap-3 z-30"
              >
                 <div className="w-8 h-8 rounded-full bg-blue-100 overflow-hidden shrink-0 border-2 border-white shadow-sm">
                   <img src={heroDoctor} className="w-full h-full object-cover" />
                 </div>
                 <div className="pr-2">
                   <div className="text-[13px] font-bold text-[#1A3454] leading-tight">@nuvica_health</div>
                   <div className="text-[10px] text-gray-500 font-semibold tracking-wide">Modern Healthcare</div>
                 </div>
              </motion.div>

              <motion.div 
                 animate={{ rotate: [0, 2, -2, 0] }}
                 transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                 className="w-[300px] h-[340px] drop-shadow-2xl"
              >
                <img src={medicalLungs} alt="Lungs" className="w-full h-full object-contain mix-blend-multiply opacity-90 rounded-full" />
              </motion.div>

              {/* Floating badge over lungs */}
              <motion.div 
                 initial={{ scale: 0 }}
                 animate={{ scale: 1 }}
                 transition={{ type: "spring", delay: 1.2 }}
                 className="absolute top-1/2 right-0 translate-x-12 -translate-y-4 bg-white/95 backdrop-blur rounded-2xl p-3 shadow-xl flex items-center gap-3 z-30"
              >
                <div className="text-[#1A3454] bg-[#F1F6FB] p-2 rounded-xl">
                  <Users size={20} strokeWidth={2.5} />
                </div>
                <div className="pr-4">
                  <div className="font-outfit font-bold text-[#1A3454] text-xl leading-none mb-0.5">6700</div>
                  <div className="text-[11px] text-gray-500 font-semibold">Healed Lungs</div>
                </div>
              </motion.div>

              <div className="absolute -bottom-8 -right-12 bg-white/70 backdrop-blur-md px-6 py-2 rounded-full text-base font-outfit font-bold text-[#1A3454] uppercase tracking-widest shadow-sm rotate-12 select-none">
                 MEDICAL
              </div>
            </div>
          </motion.div>
        </div>

        {/* Floating background pills */}
        <motion.div 
           animate={{ y: [0, -15, 0], rotate: [-12, -10, -12] }}
           transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
           className="absolute top-[480px] -left-20 bg-white/60 backdrop-blur px-6 py-2 rounded-full text-sm font-outfit font-bold text-[#1A3454] uppercase tracking-widest shadow-sm select-none"
        >
           HEALTHCARE
        </motion.div>
        <motion.div 
           animate={{ y: [0, 15, 0], rotate: [6, 8, 6] }}
           transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
           className="absolute top-[560px] left-8 bg-white/80 backdrop-blur px-5 py-2 rounded-full text-sm font-outfit font-bold text-[#1A3454] uppercase tracking-widest shadow-sm select-none"
        >
           WELLNESS
        </motion.div>

        {/* 3 Square Cards Section */}
        <motion.div 
           variants={staggerContainer}
           initial="hidden"
           whileInView="visible"
           viewport={{ once: true, margin: "-100px" }}
           className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 z-20 relative max-w-[1000px]"
        >
          {/* Card 1 */}
          <motion.div variants={fadeInUp} className="bg-white rounded-[32px] p-8 shadow-[0_8px_40px_rgb(0,0,0,0.03)] hover:-translate-y-3 transition-all duration-300 relative flex flex-col items-center justify-between aspect-[4/3] group cursor-pointer border border-[#E2EBF5]/50 hover:shadow-xl hover:shadow-black/5">
             <button className="absolute top-5 right-5 bg-[#4ADE80] text-white p-2.5 rounded-full z-10 shadow-sm opacity-5 md:opacity-100 group-hover:scale-110 group-hover:rotate-45 transition-all">
                <ArrowUpRight size={18} strokeWidth={2.5} />
             </button>
             <div className="flex-1 flex items-center justify-center w-full pt-4">
                <div className="w-[120px] h-[120px] flex items-center justify-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-[#4ADE80]/20 to-teal-100/50 rounded-[32px] rotate-3 group-hover:rotate-12 transition-transform duration-500 flex items-center justify-center text-teal-600 shadow-inner">
                    <Brain size={54} strokeWidth={1.5} className="text-teal-600 drop-shadow-sm" />
                  </div>
                </div>
             </div>
             <div className="font-outfit font-bold text-[#1A3454] text-[18px] text-center w-full leading-snug tracking-wide">Brain Health<br/>Check</div>
          </motion.div>
          
          {/* Card 2 */}
          <motion.div variants={fadeInUp} className="bg-white rounded-[32px] p-8 shadow-[0_8px_40px_rgb(0,0,0,0.03)] hover:-translate-y-3 transition-all duration-300 relative flex flex-col items-center justify-between aspect-[4/3] group cursor-pointer border border-[#E2EBF5]/50 hover:shadow-xl hover:shadow-black/5">
             <button className="absolute top-5 right-5 bg-[#4ADE80] text-white p-2.5 rounded-full z-10 shadow-sm opacity-5 md:opacity-100 group-hover:scale-110 group-hover:rotate-45 transition-all">
                <ArrowUpRight size={18} strokeWidth={2.5} />
             </button>
             <div className="flex-1 flex items-center justify-center w-full pt-4">
                <div className="w-[120px] h-[120px] flex items-center justify-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-[#4ADE80]/20 to-teal-100/50 rounded-[32px] -rotate-3 group-hover:-rotate-12 transition-transform duration-500 flex items-center justify-center shadow-inner">
                    <Activity size={54} strokeWidth={1.5} className="text-emerald-500 drop-shadow-sm" />
                  </div>
                </div>
             </div>
             <div className="font-outfit font-bold text-[#1A3454] text-[18px] text-center w-full leading-snug tracking-wide">Liver Function<br/>Test</div>
          </motion.div>
          
          {/* Card 3 - Dark Blue */}
          <motion.div variants={fadeInUp} className="bg-[#1A3454] rounded-[32px] p-8 shadow-[0_8px_40px_rgb(26,52,84,0.15)] hover:-translate-y-3 transition-all duration-300 relative flex flex-col items-center justify-between aspect-[4/3] group cursor-pointer overflow-hidden hover:shadow-xl hover:shadow-black/20">
             
             {/* Decorative Background abstract overlay */}
             <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.4),transparent_50%)] transition-opacity group-hover:opacity-30"></div>

             <button className="absolute top-5 right-5 bg-white text-[#1A3454] p-2.5 rounded-full z-10 shadow-sm opacity-5 md:opacity-100 group-hover:scale-110 group-hover:rotate-45 transition-all">
                <ArrowUpRight size={18} strokeWidth={2.5} />
             </button>
             <div className="flex-1 flex items-center justify-center w-full pt-4 relative z-10">
                <div className="w-[120px] h-[120px] flex items-center justify-center">
                  <div className="w-24 h-24 bg-white/10 backdrop-blur rounded-[32px] rotate-6 group-hover:rotate-0 transition-transform duration-500 flex items-center justify-center shadow-inner border border-white/10">
                    <Wind size={54} strokeWidth={1.5} className="text-white drop-shadow-sm" />
                  </div>
                </div>
             </div>
             <div className="font-outfit font-bold text-white text-[18px] text-center w-full leading-snug tracking-wide relative z-10">Kidney Health<br/>Scan</div>
          </motion.div>
        </motion.div>

        {/* About Us Section */}
        <div id="about" className="mt-32 grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24 items-center pl-4 py-10">
          
          {/* Left: Building Image */}
          <motion.div 
             initial={{ opacity: 0, x: -50 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true, margin: "-100px" }}
             transition={{ duration: 0.8 }}
             className="relative"
          >
            <div className="w-full aspect-[4/3] rounded-[40px] overflow-hidden shadow-2xl relative">
              <div className="absolute inset-0 bg-[#1A3454]/10 mix-blend-overlay z-10 hover:opacity-0 transition-opacity duration-700 pointer-events-none"></div>
              <motion.img 
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.8 }}
                  src={hospitalExterior} 
                  className="w-full h-full object-cover" 
              />
              <div className="absolute bottom-16 left-12 z-20 text-[#1A3454] font-outfit font-bold text-3xl rotate-12 opacity-90 mix-blend-color-burn pointer-events-none">HOSPITAL</div>
            </div>
            
            {/* Glassmorphic floating card */}
            <motion.div 
               animate={{ y: [0, -10, 0] }}
               transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
               className="absolute bg-white/80 backdrop-blur-xl rounded-[32px] p-7 top-10 -right-6 md:-right-10 w-64 shadow-[0_20px_40px_rgb(0,0,0,0.06)] border border-white"
            >
               <div className="flex items-center gap-2 mb-6">
                  <div className="bg-[#1A3454] p-1.5 rounded-lg flex items-center justify-center">
                     <Plus size={14} className="text-white" strokeWidth={3} />
                  </div>
                  <span className="font-outfit font-bold text-[#1A3454] tracking-tight text-lg">NUVICA</span>
               </div>
               
               <div className="text-[11px] uppercase font-bold text-gray-400 mb-0.5 tracking-wider">FROM</div>
               <div className="font-bold mb-6 font-outfit text-2xl text-[#1A3454]">28/10/2003</div>
               
               <div className="w-8 h-[2px] bg-gray-200 mb-6"></div>

               <p className="text-[15px] font-medium leading-snug text-[#1A3454]/80">
                 Committed to <br/>your health and <br/>well-being.
               </p>
            </motion.div>
          </motion.div>

          {/* Right: Text Content */}
          <motion.div 
             initial={{ opacity: 0, x: 50 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true, margin: "-100px" }}
             transition={{ duration: 0.8 }}
             className="flex flex-col items-start pr-0 md:pr-12"
          >
            <div className="bg-[#4ADE80] text-[#1A3454] text-[11px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest mb-6">
              About Us
            </div>
            
            <h2 className="text-[44px] md:text-[52px] font-outfit font-bold text-[#1A3454] leading-[1.05] mb-6 tracking-tight">
              YOUR NUVICA MEDICAL <br/>HOSPITAL
            </h2>
            
            <p className="text-[#1A3454]/70 font-medium text-[16px] leading-relaxed mb-10 max-w-lg">
              We Combine Clinical Expertise, Innovative Technology, And A Patient-First Approach To Ensure Accurate Diagnosis And Effective Treatment. Our commitment runs deep in providing personalized care for every individual.
            </p>
            
            <div className="flex items-center gap-8 w-full flex-wrap">
              <motion.button 
                 whileHover={{ y: -2 }}
                 whileTap={{ scale: 0.98 }}
                 className="flex items-center gap-4 bg-[#1A3454] hover:bg-[#152a45] text-white font-bold px-7 py-3.5 rounded-full transition-all group shadow-lg shadow-black/10"
              >
                 Learn More
                 <ArrowUpRight size={18} strokeWidth={2.5} className="group-hover:rotate-45 transition-transform" />
              </motion.button>
              
              <div className="flex flex-col gap-0.5 items-start">
                 <a href="tel:+18001234567" className="flex items-center gap-3 text-[#1A3454] font-bold group pb-1">
                    <div className="border-[1.5px] border-[#1A3454]/20 p-2.5 rounded-full group-hover:border-[#4ADE80] group-hover:bg-[#4ADE80]/10 transition-colors">
                       <Phone size={16} className="text-[#1A3454] group-hover:text-[#4ADE80] transition-colors" />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[#1A3454]/60 text-[11px] font-bold uppercase tracking-wider mb-0.5 group-hover:text-[#4ADE80] transition-colors">For Any Questions</span>
                      <span className="text-[16px] tracking-wide">+1 800 123 4567</span>
                    </div>
                 </a>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Stats Section */}
        <motion.div 
           variants={staggerContainer}
           initial="hidden"
           whileInView="visible"
           viewport={{ once: true, margin: "-50px" }}
           className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4 divide-y md:divide-y-0 md:divide-x divide-[#1A3454]/10 pb-24 relative"
        >
          {[
             { val: "$250M", label: "In Healthcare\nFunding" },
             { val: "20M+", label: "Patients Served\nGlobally" },
             { val: "95%", label: "Patient Satisfaction\nRate" },
             { val: "200+", label: "Medical\nProfessionals" }
          ].map((stat, i) => (
             <motion.div key={i} variants={fadeInUp} className="flex flex-col items-center text-center px-4 pt-6 md:pt-0">
               <div className="text-[42px] font-outfit font-bold text-[#1A3454] leading-none mb-3 tracking-tight">{stat.val}</div>
               <div className="text-[13px] font-semibold text-[#1A3454]/60 uppercase tracking-widest leading-relaxed whitespace-pre-line">{stat.label}</div>
             </motion.div>
          ))}
        </motion.div>

      </div>

      {/* NEW: Departments Section */}
      <div id="departments" className="bg-white py-24 border-t border-gray-100 relative overflow-hidden">
        {/* Subtle background blob */}
         <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#E2EBF5]/50 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/4 pointer-events-none"></div>

         <div className="max-w-[1240px] mx-auto px-6 relative z-10">
           <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-8">
              <motion.div 
                 initial={{ opacity: 0, y: 30 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ duration: 0.6 }}
                 className="max-w-2xl"
              >
                  <div className="bg-[#4ADE80]/20 text-[#1A3454] text-[11px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest mb-6 w-fit">
                    Our Departments
                  </div>
                  <h2 className="text-[44px] md:text-[52px] font-outfit font-bold text-[#1A3454] leading-[1.05] tracking-tight">
                    World-Class Facilities & Specialized Care
                  </h2>
              </motion.div>
              <motion.button 
                 initial={{ opacity: 0, x: 30 }}
                 whileInView={{ opacity: 1, x: 0 }}
                 viewport={{ once: true }}
                 whileHover={{ x: 5 }}
                 className="flex items-center gap-2 text-[#4ADE80] font-bold text-[15px] group whitespace-nowrap"
              >
                 View All Departments
                 <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </motion.button>
           </div>

           <motion.div 
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
           >
              {departments.map((dept, i) => (
                <motion.div 
                   key={i} 
                   variants={fadeInUp}
                   whileHover={{ y: -5 }}
                   className="bg-[#F8FAFC] border border-gray-100 p-8 rounded-[32px] group hover:shadow-xl hover:shadow-black/5 transition-all duration-300"
                >
                   <div className={`w-14 h-14 ${dept.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                      <dept.icon size={28} strokeWidth={2} />
                   </div>
                   <h3 className="text-xl font-outfit font-bold text-[#1A3454] mb-3">{dept.name}</h3>
                   <p className="text-[#1A3454]/60 font-medium leading-relaxed mb-6">{dept.desc}</p>
                   <button className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-[#1A3454] group-hover:bg-[#1A3454] group-hover:text-white transition-colors group-hover:border-[#1A3454]">
                      <ArrowRight size={18} />
                   </button>
                </motion.div>
              ))}
           </motion.div>
         </div>
      </div>

      {/* NEW: Doctors Section */}
      <div id="doctors" className="py-24 bg-gradient-to-b from-[#F1F6FB] to-white relative">
         <div className="max-w-[1240px] mx-auto px-6 relative z-10">
            <motion.div 
               initial={{ opacity: 0, y: 30 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               className="text-center flex flex-col items-center mb-16"
            >
               <div className="bg-[#4ADE80] text-[#1A3454] text-[11px] font-bold px-4 py-1.5 rounded-full uppercase tracking-widest mb-6">
                 Expert Team
               </div>
               <h2 className="text-[44px] md:text-[52px] font-outfit font-bold text-[#1A3454] leading-[1.05] tracking-tight max-w-2xl">
                 Meet Our Experienced Specialists
               </h2>
            </motion.div>

            <motion.div 
               variants={staggerContainer}
               initial="hidden"
               whileInView="visible"
               viewport={{ once: true, margin: "-100px" }}
               className="grid grid-cols-1 md:grid-cols-3 gap-8"
            >
               {doctors.map((doctor, i) => (
                  <motion.div 
                     key={i} 
                     variants={fadeInUp}
                     className="bg-white rounded-[32px] overflow-hidden shadow-[0_8px_40px_rgb(0,0,0,0.04)] group border border-gray-100"
                  >
                     <div className="h-[320px] bg-[#E2EBF5] overflow-hidden relative">
                        <img 
                           src={doctor.img} 
                           alt={doctor.name} 
                           className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-700"
                        />
                        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#1A3454]/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6 gap-4">
                           <button className="bg-white/20 backdrop-blur p-2 rounded-full text-white hover:bg-[#4ADE80] hover:text-[#1A3454] transition-colors"><Linkedin size={18} /></button>
                           <button className="bg-white/20 backdrop-blur p-2 rounded-full text-white hover:bg-[#4ADE80] hover:text-[#1A3454] transition-colors"><Twitter size={18} /></button>
                        </div>
                     </div>
                     <div className="p-8 text-center bg-white relative z-10">
                        <h3 className="text-xl font-outfit font-bold text-[#1A3454] mb-1">{doctor.name}</h3>
                        <p className="text-[#4ADE80] font-bold text-sm tracking-wide uppercase">{doctor.role}</p>
                     </div>
                  </motion.div>
               ))}
            </motion.div>
         </div>
      </div>

      {/* NEW: CTA / Booking Section */}
      <div className="py-24 max-w-[1240px] mx-auto px-6 relative z-10">
         <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-[#1A3454] rounded-[48px] p-12 md:p-20 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-12"
         >
            {/* Background elements */}
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#4ADE80]/20 blur-3xl rounded-full"></div>
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/20 blur-3xl rounded-full"></div>
            
            <div className="relative z-10 max-w-xl">
               <h2 className="text-[40px] md:text-[48px] font-outfit font-bold text-white leading-[1.1] tracking-tight mb-6">
                 Need a Doctor for Checkup? Book an Appointment.
               </h2>
               <p className="text-white/70 text-lg mb-0 font-medium">
                 Get quality healthcare at your convenience. Our specialists are ready to help you directly.
               </p>
            </div>

            <div className="relative z-10 flex flex-col gap-4 w-full md:w-auto">
               <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-[#4ADE80] text-[#1A3454] font-bold px-8 py-4 rounded-full text-lg shadow-xl shadow-[#4ADE80]/20 flex items-center justify-center gap-2"
               >
                 <Clock size={20} />
                 Schedule Now
               </motion.button>
               <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-white/10 text-white font-bold px-8 py-4 rounded-full text-lg backdrop-blur hover:bg-white/20 transition-colors flex items-center justify-center gap-2"
               >
                 <Phone size={20} />
                 Call 1-800-NUVICA
               </motion.button>
            </div>
         </motion.div>
      </div>

      {/* Footer */}
      <footer id="contact" className="bg-white pt-20 pb-10 border-t border-gray-200">
         <div className="max-w-[1240px] mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
               
               {/* Brand Col */}
               <div className="col-span-1 md:col-span-1">
                  <div className="flex items-center gap-2 mb-6">
                     <div className="bg-[#1A3454] p-1.5 rounded-lg flex items-center justify-center w-8 h-8">
                       <Plus size={20} className="text-[#4ADE80]" strokeWidth={3} />
                     </div>
                     <span className="text-2xl font-bold font-outfit text-[#1A3454] tracking-tight">Nuvica</span>
                  </div>
                  <p className="text-[#1A3454]/60 font-medium leading-relaxed mb-6">
                    Providing world-class medical services since 2003 with a focus on compassionate care and advanced technology.
                  </p>
                  <div className="flex items-center gap-4 text-[#1A3454]">
                     <a href="#" className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-[#4ADE80] hover:text-white transition-colors"><Facebook size={18} /></a>
                     <a href="#" className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-[#4ADE80] hover:text-white transition-colors"><Twitter size={18} /></a>
                     <a href="#" className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-[#4ADE80] hover:text-white transition-colors"><Instagram size={18} /></a>
                  </div>
               </div>

               {/* Quick Links */}
               <div>
                  <h4 className="font-outfit font-bold text-[#1A3454] text-lg mb-6">Quick Links</h4>
                  <ul className="flex flex-col gap-4 font-medium text-[#1A3454]/70">
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">About Us</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Our Doctors</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Departments</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Career Options</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">News & Blog</a></li>
                  </ul>
               </div>

               {/* Services */}
               <div>
                  <h4 className="font-outfit font-bold text-[#1A3454] text-lg mb-6">Services</h4>
                  <ul className="flex flex-col gap-4 font-medium text-[#1A3454]/70">
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Cardiology Checkup</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Neurology Care</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Laboratory Tests</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Emergency Services</a></li>
                     <li><a href="#" className="hover:text-[#4ADE80] transition-colors">Dental Surgeries</a></li>
                  </ul>
               </div>

               {/* Contact */}
               <div>
                  <h4 className="font-outfit font-bold text-[#1A3454] text-lg mb-6">Contact Us</h4>
                  <ul className="flex flex-col gap-5 font-medium text-[#1A3454]/70">
                     <li className="flex items-start gap-4">
                        <MapPin size={20} className="text-[#4ADE80] shrink-0 mt-0.5" />
                        <span>123 Medical Drive,<br/>New Health City, NY 10001</span>
                     </li>
                     <li className="flex items-center gap-4">
                        <Phone size={20} className="text-[#4ADE80] shrink-0" />
                        <span>+1 800 123 4567</span>
                     </li>
                     <li className="flex items-center gap-4">
                        <Mail size={20} className="text-[#4ADE80] shrink-0" />
                        <span>contact@nuvicahealth.com</span>
                     </li>
                  </ul>
               </div>

            </div>

            <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row items-center justify-between gap-4 text-[#1A3454]/50 font-medium text-sm">
               <p>© 2026 Nuvica Medical. All rights reserved.</p>
               <div className="flex gap-6">
                 <a href="#" className="hover:text-[#1A3454]">Privacy Policy</a>
                 <a href="#" className="hover:text-[#1A3454]">Terms of Service</a>
               </div>
            </div>
         </div>
      </footer>
    </div>
  );
}
